Simplex Calculator
==================

Live demo: http://simplex.tode.cz

This is a simple PHP tool for linear programming problems solving using dual simplex algorithm.

It can detect none, one and only and more optimal solutions to any linear problem you tell it to solve.

However, the only thing that has been left unimplemented is basis cycling detection. Feel free to post pull requests ;-)

Enjoy.


Conventions
-----------

Please name your variables as **x&lt;n&gt;** where *&lt;n&gt;* is a natural number (see [example.php](https://github.com/uestla/Simplex-Calculator/blob/master/example.php) for details).
