<?php

require_once __DIR__ . '/Helpers.php';
require_once __DIR__ . '/Fraction.php';
require_once __DIR__ . '/VariableSet.php';
require_once __DIR__ . '/Func.php';
require_once __DIR__ . '/ValueFunc.php';
require_once __DIR__ . '/Restriction.php';
require_once __DIR__ . '/Task.php';
require_once __DIR__ . '/TableRow.php';
require_once __DIR__ . '/Table.php';
require_once __DIR__ . '/Solver.php';
