<?php

require_once __DIR__ . '/../Simplex/simplex.php';
require_once __DIR__ . '/../vendor/autoload.php';

Tester\Environment::setup();
