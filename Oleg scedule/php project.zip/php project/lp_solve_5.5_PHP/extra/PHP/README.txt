See PHP.htm and changes for more information
