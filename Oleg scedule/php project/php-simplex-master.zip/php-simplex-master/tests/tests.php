<?php

require_once '../vendor/php-matrix-decompositions/lib/Assertion.php';
require_once '../vendor/php-matrix-decompositions/lib/Vector.php';
require_once '../vendor/php-matrix-decompositions/lib/Matrix.php';
require_once '../lib/Dictionary.php';
require_once '../lib/DictionaryIO.php';